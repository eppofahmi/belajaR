::: {.columns}
::: {.column width="50%"}

Contents....

:::
  
::: {.column width="50%"}

Contents....

:::
:::